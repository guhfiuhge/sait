import './Contacts.css';

function Contacts() {
	return (
		<div className="contacts">
			<div className="contacts-content">
				<h1>Контакты</h1>
				<div className="contacts-info">
					<p>Контактная информация</p>
				</div>
			</div>
		</div>
	);
}

export default Contacts;