import './Delivery.css';

function Delivery() {
	return (
		<div className="delivery">
			<div className="delivery-content">
				<h1>Доставка</h1>
				<div className="delivery-info">
					<p>Информация о доставке</p>
				</div>
			</div>
		</div>
	);
}

export default Delivery;